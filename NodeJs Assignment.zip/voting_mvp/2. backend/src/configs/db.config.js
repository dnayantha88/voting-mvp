import AwsSdk from 'aws-sdk';

/**
 * Singleton class to make DB connection
 */
class DbConfig {
    static instance = null;
  
    static getInstance() {
        if (DbConfig.instance == null) {
            DbConfig.instance = new DbConfig();
        }
        return this.instance;
    }

    // DynamoDB DocumentClient method
    get documentClient() {
        if (!this.docClient)
            this.docClient = new AwsSdk.DynamoDB.DocumentClient();
        
        return this.docClient;
    }

}

export default DbConfig;
