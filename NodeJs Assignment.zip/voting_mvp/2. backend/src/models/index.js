import votingModel from './votingModel';

export {
    votingModel
    
    // future models comes here
}