import DbConfig from "../configs/db.config";
import { CONTESTERS_TABLE } from "../constants/dbConstants";

// create DynamoDB instance
const { documentClient: dynamo } = DbConfig.getInstance();

const votingModel = {
    /**
     * query db to get contester's details
     * @param {string} id 
     */
    getContesterById: async (id) => {
        const params = {
            TableName: CONTESTERS_TABLE,
            Key: {
                ContesterId: id
            }
        }
        // const result = await dynamo.get(params).promise();
        // return result.Item

        // moked result
        return { contesterId: "mv33", name: "Jhon" };
    },

    /**
     * insert vote to table
     * @param {string} id 
     * @param {string} timestamp
     */
    recordVote: async (id, timestamp) => {
        // await dynamo.put()
    },

    /**
     * query all contesters
     */
    getAllContesters: async () => {
        // await dynamo.scan()

        return [
            { contesterId: "mv33", name: "Jhon" },
            { contesterId: "mv44", name: "Simon" },
        ]
    },

    /**
     * query votes per constester
     * @param {string} id 
     */
    getVotesById: async (id) => {
        // await dynamo.query()

        // mocked query result
        let votes = [];
        switch (id) {
            case "mv33":
                votes = [
                    { id: "uuid1", contesterId: "mv33", timestam: "2022-10-03T04:41:04.115z" },
                    { id: "uuid2", contesterId: "mv33", timestam: "2022-10-03T04:41:04.115z" },
                ];
                break;
            case "mv44":
                votes = [
                    { id: "uuid1", contesterId: "mv44", timestam: "2022-10-03T04:41:04.115z" },
                    { id: "uuid2", contesterId: "mv44", timestam: "2022-10-03T04:41:04.115z" },
                    { id: "uuid2", contesterId: "mv44", timestam: "2022-10-03T04:41:04.115z" },
                    { id: "uuid2", contesterId: "mv44", timestam: "2022-10-03T04:41:04.115z" },
                ];
                break;
        }
        return votes;
    },
}

export default votingModel;
