// database constants

const CONTESTERS_TABLE = "CONTESTERS"; // contesters table name
const VOTING_TABLE = "VOTES"; // voting table name

export {
    CONTESTERS_TABLE,
    VOTING_TABLE

    // future constants comes here
}