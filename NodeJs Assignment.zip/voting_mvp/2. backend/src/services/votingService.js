import { votingModel } from '../models';

/**
 * Method to record votes
 * @param {string} id contestant's id
 * @param {string} timestamp 
 */
const recordVote = async (id, timestamp) => {
    /**
     * validating params
     * TODO: use joi validation with a helper method
     */
    if (!id || !timestamp) {
        throw new Error("Error: missing required params");
    }

    // check the contester is valid by contestant's id
    const contestant = await votingModel.getContesterById(id);
    if (!contestant) {
        throw new Error("Error: invalid contestant id");
    }

    // record vote to db table
    await votingModel.recordVote(id, timestamp);
}

/**
 * method to get votes per each contester
 * @returns [{votes, name}]
 */
const getVotesCount = async () => {
    const result = [];

    /**
     * get all contesters
     * [{ id, contestantName }]
     */
    const contesters = await votingModel.getAllContesters();

    for (const contestant of contesters) {
        const { contesterId, name } = contestant;

        // get all votes per contester by contester's id
        const contesterVotes = await votingModel.getVotesById(contesterId);

        /**
         * TODO: a validation to filter votes only within a given timeframe
         */

        result.push({
            votes: contesterVotes.length,
            name
        })
    }
    return result;
}

export {
    recordVote,
    getVotesCount
}