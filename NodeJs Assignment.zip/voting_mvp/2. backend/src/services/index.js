import * as votingService from './votingService';

export {
    votingService
    // future services comes here
}