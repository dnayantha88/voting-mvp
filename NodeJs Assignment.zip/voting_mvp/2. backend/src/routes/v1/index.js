import votingRouter from './votingRouter';
import otherRouters from './otherRoutes';

export {
    votingRouter,
    otherRouters
    // future routes comes here
}