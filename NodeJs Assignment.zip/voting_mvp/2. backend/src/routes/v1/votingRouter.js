import express from 'express';
import { votingService } from '../../services';
import { jwtValidator } from '../../middlewares/auth';

const router = express.Router();

// api to record votes
router.post('/', jwtValidator, async ({ body }, res) => {
    const { contestantId, timestamp } = body;
    try {
        await votingService.recordVote(contestantId, timestamp);
        res.status(200).send({ success: true, data: {}, message: "Vote successfully recorded" });
    } catch (e) {
        console.log('Error in creating vote: ', e)
        res.status(500).send({ success: false, error: 'Error in creating vote' })
    }
});

// api to get all votes per contester
router.get('/', jwtValidator, async (req, res) => {
    try {
        const result = await votingService.getVotesCount();
        res.status(200).send({ success: true, data: result, message: "Votes count successfully fetched" });
    } catch (e) {
        console.log('Error in getting votes count: ', e)
        res.status(500).send({ success: false, error: 'Error in getting votes count' })
    }
});

export default router;
