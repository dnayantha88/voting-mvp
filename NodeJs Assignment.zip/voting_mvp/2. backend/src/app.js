import express from 'express';
import cors from 'cors';
import { votingRouter } from './routes/v1';

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

// initializing api routes
app.use(
    "/votemvp/api/v1/vote",
    votingRouter
);
// future routes comes here

const port = 8080;
app.listen(port, () => {
    console.log(`⚡️ app listening at http://localhost:${port}`);
});

export default app;
