// middleware to validate APIs
export const jwtValidator = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        res.status(401).send({ success: false, error: 'Unauthorized' })
    }

    /**
     * TODO: validate token with jwt lib
     */
    next();
}